public class App {
    public static void main(String[] args) throws Exception {
        var students = Parser.parseStudents();
        for(var student : students){
            System.out.println(student);
        }
    }
}
