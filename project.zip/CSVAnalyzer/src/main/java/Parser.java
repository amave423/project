import com.opencsv.CSVReader;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Parser {
    public static List<Student> parseStudents() throws Exception {
        var students = new ArrayList<Student>();

        var reader = Files.newBufferedReader(Paths.get("src/main/resources/parse.csv"));
        var csvReader = new CSVReader(reader);
        csvReader.readNext();
        csvReader.readNext();
        csvReader.readNext();

        String[] record;
        while ((record = csvReader.readNext()) != null) {
            var data = record[0].split(" ", 2);

            var name = data[0];
            var surname = data.length == 2 ? data[1] : null;
            var uid = record[1];
            var email = record[2];
            var group = record[3];

            var student = getStudent(uid, name, surname, email, group);
            students.add(student);
        }
        return students;
    }

    private static Student getStudent(String uid, String name, String surname, String email, String group) {
        var student = new Student();
        student.setUid(uid);
        student.setName(name);
        student.setSurname(surname);
        student.setEmail(email);
        student.setGroup(group);
        return student;
    }
}
