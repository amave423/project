package db;

import dao.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class Database {

    private Connection connection;

    public void fill(String pathToDb, List<Student> students) throws ClassNotFoundException, SQLException{
        Class.forName("org.sqlite.JDBC");
        connection = DriverManager.getConnection(pathToDb);
        connection.setAutoCommit(false);

        createSchema();

        for (var student : students){
            var uid = insert(student);
            for (var lesson : student.getCourseInfo().getLessonList()){
                var lesson_id = insert(lesson,uid);

                for (var hw : lesson.getHomework())
                    insert(hw,lesson_id,"homework");
                for (var ex : lesson.getExercise())
                    insert(ex,lesson_id,"exercise");


            }
        }


        connection.commit();
        connection.rollback();
        connection.close();
    }

    private void insert(LessonItem lessonItem, long lessonId, String tableName) throws SQLException{
        System.out.println(lessonItem);
        try (
                var statement = connection.prepareStatement("INSERT INTO '"+tableName+"' ('title','points','lesson_id') VALUES (?,?,?);",
                        Statement.RETURN_GENERATED_KEYS);
        ) {
            statement.setString(1, lessonItem.getTitle());
            statement.setLong(2, lessonItem.getPoints());
            statement.setLong(3, lessonId);

            statement.executeUpdate();
        }
    }


    private String insert(Student student) throws SQLException{
        System.out.println(student);
        try (
                var statement = connection.prepareStatement("INSERT INTO 'student' ('uid','firstname','lastname','email','group') VALUES (?,?,?,?,?);",
                        Statement.RETURN_GENERATED_KEYS);
        ) {
            statement.setString(1, student.getUid());
            statement.setString(2, student.getFirstname());
            statement.setString(3, student.getLastname());
            statement.setString(4, student.getEmail());
            statement.setString(5, student.getGroup());
            statement.executeUpdate();
            return student.getUid();
        }
    }

    private long insert(Lesson lesson, String student_uid) throws SQLException {
        System.out.println(lesson);
        try (
                var statement = connection.prepareStatement("INSERT INTO 'lesson' ('title','activityPoints','semPoints','student_uid') VALUES (?,?,?,?);",
                        Statement.RETURN_GENERATED_KEYS);
        ) {
            statement.setString(1, lesson.getTitle());
            statement.setLong(2, lesson.getActivityPoints());
            statement.setLong(3, lesson.getSemPoints());
            statement.setString(4, student_uid);

            int affectedRows = statement.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Creating user failed, no rows affected.");
            }

            try (var generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    var lesson_id = generatedKeys.getLong(1);
                    return lesson_id;
                }
                else {
                    throw new SQLException("Creating user failed, no ID obtained.");
                }
            }
        }
    }

    private void createSchema() throws SQLException {
        var statement = connection.createStatement();
        statement.execute(
                "CREATE TABLE IF NOT EXISTS 'student' (" +
                        "'uid' VARCHAR PRIMARY KEY, " +
                        "'firstname' VARCHAR, " +
                        "'lastname' VARCHAR, " +
                        "'email' VARCHAR, " +
                        "'group' VARCHAR);");

        statement.execute(
                "CREATE TABLE IF NOT EXISTS 'lesson' (" +
                        "'id' INTEGER PRIMARY KEY, " +
                        "'title' VARCHAR, " +
                        "'activityPoints' INTEGER, " +
                        "'student_uid' VARCHAR, " +
                        "'semPoints' INTEGER);");
        statement.execute(
                "CREATE TABLE IF NOT EXISTS 'homework' (" +
                        "'id' INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "'lesson_id' INTEGER, " +
                        "'points' INTEGER, " +
                        "'title' varchar);");
        statement.execute(
                "CREATE TABLE IF NOT EXISTS 'exercise' (" +
                        "'id' INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "'lesson_id' INTEGER, " +
                        "'points' INTEGER, " +
                        "'title' varchar);");


    }
}
