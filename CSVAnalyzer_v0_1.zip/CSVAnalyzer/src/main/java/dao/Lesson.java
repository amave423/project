package dao;

import java.util.ArrayList;
import java.util.List;

public class Lesson {
    private String title;
    private int activityPoints;
    private int semPoints;

    private final List<Exercise> exerciseList = new ArrayList<>();
    private final List<Homework> homeworkList = new ArrayList<>();

    public Lesson(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return "Lesson{" +
                "title='" + title + '\'' +
                ", activityPoints=" + activityPoints +
                ", semPoints=" + semPoints +
                ", uprList=" + exerciseList +
                ", dzList=" + homeworkList +
                '}';
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getActivityPoints() {
        return activityPoints;
    }

    public void setActivityPoints(int activityPoints) {
        this.activityPoints = activityPoints;
    }

    public int getSemPoints() {
        return semPoints;
    }

    public void setSemPoints(int semPoints) {
        this.semPoints = semPoints;
    }

    public List<Exercise> getExercise() {
        return exerciseList;
    }

    public List<Homework> getHomework() {
        return homeworkList;
    }
}
