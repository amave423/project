package dao;

public class Exercise extends LessonItem {
    public Exercise(String title, int ponts) {
        super(title, ponts);
    }


}
