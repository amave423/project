package dao;

import java.util.ArrayList;
import java.util.List;

public class CourseInfo {
    private final List<Lesson> lessonList = new ArrayList<>();

    public List<Lesson> getLessonList() {
        return lessonList;
    }

    @Override
    public String toString() {
        return "Course{" +
                "lessonList=" + lessonList +
                '}';
    }
}
