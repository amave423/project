package dao;

public class LessonItem {
    private String title;
    private int points;

    public LessonItem(String title, int points) {
        this.title = title;
        this.points = points;
    }

    @Override
    public String toString() {
        return "UPDZ{" +
                "title='" + title + '\'' +
                ", ponts=" + points +
                '}';
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }
}
