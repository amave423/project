package dao;

public class Homework extends LessonItem {
    public Homework(String title, int ponts) {
        super(title, ponts);
    }
}
