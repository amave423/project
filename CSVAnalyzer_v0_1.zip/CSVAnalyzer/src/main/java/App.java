import com.opencsv.exceptions.CsvValidationException;
import db.Database;

import java.io.IOException;
import java.sql.SQLException;

public class App {

    private final static String pathToDb = "jdbc:sqlite:src/main/resources/database.db";


    public static void main(String[] args) throws CsvValidationException, IOException, SQLException, ClassNotFoundException {
        var students = new Parser().parseStudents();

        var db = new Database();
//        db.fill(pathToDb,students);
    }
}
