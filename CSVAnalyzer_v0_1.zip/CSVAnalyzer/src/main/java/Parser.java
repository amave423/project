import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import dao.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Parser {
    public List<Student> parseStudents() throws IOException, CsvValidationException {
        var students = new ArrayList<Student>();

        var reader = Files.newBufferedReader(Paths.get("src/main/resources/parse.csv"));
        var csvReader = new CSVReader(reader);
        var headName = csvReader.readNext();
        var subName = csvReader.readNext();
        var scores = csvReader.readNext();

        String[] record;
        while ((record = csvReader.readNext()) != null) {
            var data = record[0].split(" ", 2);

            var name = data[0];
            var surname = data.length == 2 ? data[1] : null;
            var uid = record[1];
            var email = record[2];
            var group = record[3];

            var student = getStudent(uid, name, surname, email, group);
            var courseInfo = parseCourseInfo(headName,subName,record);

            student.setCourseInfo(courseInfo);
            students.add(student);
        }
        return students;
    }
    private CourseInfo parseCourseInfo(String[] name, String[] subName, String[] scores)  {
        var course = new CourseInfo();

        for (int i = 0; i < name.length; i++) {
            var head = i;
            if(!name[i].isEmpty()){
                var lesson = new Lesson(name[i]);


                if(subName[i].equals("Акт"))
                    lesson.setActivityPoints(Integer.parseInt(scores[i]));
                if(subName[i].equals("Сем"))
                    lesson.setSemPoints(Integer.parseInt(scores[i]));

                i++;
                while (i < name.length && name[i].isEmpty()){
                    var points = Integer.parseInt(scores[i]);
                    if(subName[i].equals("Акт"))
                        lesson.setActivityPoints(points);
                    else if(subName[i].equals("Сем"))
                        lesson.setSemPoints(points);
                    else if(subName[i].startsWith("Упр:")){
                        lesson.getExercise().add(new Exercise(subName[i],points));
                    } else if(subName[i].startsWith("ДЗ:")){
                        lesson.getHomework().add(new Homework(subName[i],points));
                    }
                    i++;
                }
                course.getLessonList().add(lesson);

            }
            i = head;
        }
        return course;
    }

    private Student getStudent(String uid, String name, String surname, String email, String group) {
        var student = new Student();
        student.setUid(uid);
        student.setFirstname(name);
        student.setLastname(surname);
        student.setEmail(email);
        student.setGroup(group);
        return student;
    }
}
